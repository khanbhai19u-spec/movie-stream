# Flixora

SparkBox-এর নতুন নাম ও নতুন ডিজাইন। নীল-সায়ান ডার্ক UI, SparkBoxCore (Rust) FFI-র উপর চলে।

## সেটআপ (একবারই)

```bash
# 1) এই ফোল্ডারের ভেতরে Android/iOS ফোল্ডার তৈরি করো (lib/ ও pubspec.yaml অক্ষত থাকবে)
flutter create . --project-name flixora --org com.flixora --platforms android,ios

# 2) প্যাকেজ আনো
flutter pub get

# 3) অ্যাপ আইকন জেনারেট করো (assets/icon.png থেকে)
dart run flutter_launcher_icons

# 4) অ্যাপের নাম "Flixora" করো
#    android/app/src/main/AndroidManifest.xml -> android:label="Flixora"
#    ios/Runner/Info.plist -> CFBundleDisplayName = Flixora
```

## Rust কোর যুক্ত করা

SparkBoxCore থেকে নেটিভ লাইব্রেরি বানাও:

```bash
cd SparkBoxCore-main
cargo install cargo-ndk
cargo ndk -t arm64-v8a -t armeabi-v7a -t x86_64 \
  -o ../flixora/android/app/src/main/jniLibs build --release -p sparkbox-ffi
```

তারপর `flutter run`।

## ফোল্ডার

- `lib/core/sparkbox_core.dart` — কোরের মূল বাইন্ডিং (অপরিবর্তিত)
- `lib/core/repository.dart` — টাইপ করা facade
- `lib/screens/` — Home, Search, Detail, Player
- `lib/widgets/` — হিরো ক্যারোসেল, পোস্টার কার্ড, সেকশন রো, লোগো
- `assets/` — `logo.svg`, `logo.png`, `icon.png`, `icon_fg.png`

## রং বদলাতে

`lib/theme.dart`-এর `FX` ক্লাসে `blue` ও `cyan` পরিবর্তন করো।

## GitHub দিয়ে APK বানানো (লোকাল সেটআপ ছাড়া)

1. GitHub-এ নতুন repo বানাও এবং এই ফোল্ডারের সব ফাইল (`.github` সহ) `main` ব্রাঞ্চে পুশ করো।
2. repo-র **Actions → Build Flixora APK → Run workflow** চালাও (পুশ করলেও নিজে চলবে)।
3. শেষ হলে রান পেজের নিচে **Artifacts → flixora-apk** থেকে APK নামাও (arm64-v8a ফাইলটা বেশিরভাগ ফোনে চলে)।

`.github/workflows/build-apk.yml`-এর `CORE_REPO` তোমার SparkBoxCore repo-র নামে সেট করা আছে (`devfahim00/SparkBoxCore`)। অন্য নামে হলে বদলে নিও। কোর repo প্রাইভেট হলে সেই checkout ধাপে `token:` হিসেবে একটা PAT দিতে হবে।
